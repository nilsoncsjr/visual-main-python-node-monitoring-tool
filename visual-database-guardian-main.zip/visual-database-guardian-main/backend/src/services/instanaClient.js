// backend/src/services/instanaClient.js
const axios = require('axios');
const logger = require('../utils/logger');
const settings = require('../config/settings');

const BASE_URL = settings.INSTANA_BASE_URL;
const API_TOKEN = settings.INSTANA_API_TOKEN;
const TIMEOUT = settings.REQUEST_TIMEOUT_SECONDS * 1000;

// Helper to build correct API URL
function joinApiPath(path) {
  // If BASE already ends with /api, don't duplicate
  if (BASE_URL.endsWith('/api')) {
    return `${BASE_URL}${path}`;
  }
  return `${BASE_URL}/api${path}`;
}

class InstanaClient {
  constructor() {
    this.baseUrl = BASE_URL;
    this.headers = API_TOKEN ? { 'Authorization': `apiToken ${API_TOKEN}` } : {};
    this.timeout = TIMEOUT;
    this.cache = new Map(); // key -> { timestamp, data }
    
    if (!this.baseUrl || !API_TOKEN) {
      logger.warn('Instana BASE_URL or API_TOKEN not configured (check environment variables)');
      logger.warn(`BASE_URL configured: ${!!this.baseUrl}, API_TOKEN configured: ${!!API_TOKEN}`);
    } else {
      logger.info(`Instana client initialized with base URL: ${this.baseUrl}`);
    }
  }

  isConfigured() {
    return !!(this.baseUrl && this.headers.Authorization);
  }

  _getCached(key, ttlMs = 55000) {
    const cached = this.cache.get(key);
    if (cached && (Date.now() - cached.timestamp) < ttlMs) {
      return cached.data;
    }
    return null;
  }

  _setCached(key, data) {
    this.cache.set(key, { timestamp: Date.now(), data });
  }

  async _get(path, params = {}) {
    const url = joinApiPath(path);
    try {
      const response = await axios.get(url, {
        params,
        headers: this.headers,
        timeout: this.timeout
      });
      return response.data;
    } catch (error) {
      if (error.response?.status === 401) {
        logger.error(`Instana API authentication failed for ${path}: Check your API token`);
      } else {
        logger.error(`Instana API GET error for ${path}:`, error.message);
      }
      if (error.response) {
        logger.error(`Status: ${error.response.status}, Data: ${JSON.stringify(error.response.data).substring(0, 400)}`);
      }
      throw error;
    }
  }

  async _post(path, body = {}) {
    const url = joinApiPath(path);
    try {
      const response = await axios.post(url, body, {
        headers: { ...this.headers, 'Content-Type': 'application/json' },
        timeout: this.timeout
      });
      return response.data;
    } catch (error) {
      logger.error(`Instana API POST error for ${path}:`, error.message); // Never log the token
      if (error.response) {
        logger.error(`Status: ${error.response.status}, Data: ${JSON.stringify(error.response.data).substring(0, 400)}`);
      }
      throw error;
    }
  }

  // Use snapshots instead of /infrastructure/resources
  async listEntities(plugin, ttlMs = 55000) {
    const cacheKey = `snapshots:${plugin}`;
    const cached = this._getCached(cacheKey, ttlMs);
    if (cached) return cached;

    try {
      const data = await this._get('/infrastructure-monitoring/snapshots', {
        query: `entity.selfType:${plugin}`,
        windowSize: 60 * 60 * 1000, // 1 hour window
        pageSize: 500
      });
      const items = data.items || [];
      this._setCached(cacheKey, items);
      return items;
    } catch (error) {
      logger.error(`Failed to list ${plugin} snapshots:`, error.message);
      return [];
    }
  }

  // Use POST /infrastructure-monitoring/metrics for batch metrics
  async metricsLatest(plugin, snapshotIds, metricKeys, windowMs = 15 * 60 * 1000, rollupSeconds = 60) {
    // 1) Filter valid IDs
    const validSnapshotIds = snapshotIds
      .filter(id => typeof id === 'string' && id.trim())
      .map(id => id.trim());
    
    if (validSnapshotIds.length === 0) {
      return {};
    }

    // 2) Filter valid and unique metrics
    const seen = new Set();
    const validMetricKeys = metricKeys.filter(m => {
      if (typeof m === 'string' && m.trim() && !seen.has(m)) {
        seen.add(m);
        return true;
      }
      return false;
    });

    if (validMetricKeys.length === 0) {
      return {};
    }

    // 3) Chunk metrics to max 5 per request
    const chunkArray = (arr, size) => {
      const chunks = [];
      for (let i = 0; i < arr.length; i += size) {
        chunks.push(arr.slice(i, i + size));
      }
      return chunks;
    };

    const result = {};
    const now = Date.now();

    // Process each chunk of metrics
    for (const metricChunk of chunkArray(validMetricKeys, 5)) {
      const body = {
        metrics: metricChunk,  // array of strings, max 5
        plugin: plugin,
        snapshotIds: validSnapshotIds,
        rollup: rollupSeconds,
        timeFrame: { 
          windowSize: windowMs,
          to: now
        }
      };

      try {
        const data = await this._post('/infrastructure-monitoring/metrics', body);
        const items = data.items || (Array.isArray(data) ? data : []);

        for (const item of items) {
          const sid = (item.snapshotId || item.id || '').trim();
          if (!sid) continue;
          
          const metricsData = item.metrics || {};
          if (!result[sid]) {
            result[sid] = {};
          }

          for (const [key, series] of Object.entries(metricsData)) {
            if (Array.isArray(series) && series.length > 0) {
              // Get the most recent non-null value
              for (let i = series.length - 1; i >= 0; i--) {
                const [, value] = series[i];
                if (value !== null && value !== undefined) {
                  result[sid][key] = parseFloat(value);
                  break;
                }
              }
            }
          }
        }
      } catch (error) {
        logger.error(`Failed to get metrics chunk for ${plugin}:`, error.message);
        // Continue with next chunk
      }
    }

    return result;
  }
}

// Singleton instance
let instanaClient = null;

function getInstance() {
  if (!instanaClient) {
    instanaClient = new InstanaClient();
  }
  return instanaClient;
}

module.exports = { InstanaClient, getInstance };