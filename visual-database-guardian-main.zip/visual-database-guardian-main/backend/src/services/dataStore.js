const logger = require('../utils/logger');

class DataStore {
  constructor() {
    this.servers = new Map();
    this.alerts = [];
    this.connectionMetrics = {
      total: 0,
      active: 0,
      failed: 0,
      idle: 0
    };
    this.metricsHistory = new Map(); // Metrics history per server
    this.maxHistorySize = 288; // 24 hours with collections every 5 minutes
  }

  updateServerMetrics(serverId, serverName, metrics) {
    const server = this.servers.get(serverId) || {
      id: serverId,
      name: serverName,
      status: 'unknown',
      lastChecked: null
    };

    server.status = 'healthy';
    server.lastChecked = new Date();
    server.currentMetrics = metrics;

    this.servers.set(serverId, server);

    // Add to history
    this.addToHistory(serverId, metrics);
  }

  updateServerStatus(serverId, serverName, status) {
    const server = this.servers.get(serverId) || {
      id: serverId,
      name: serverName,
      status: 'unknown',
      lastChecked: null
    };

    server.status = status;
    server.lastChecked = new Date();

    this.servers.set(serverId, server);
  }

  addToHistory(serverId, metrics) {
    if (!this.metricsHistory.has(serverId)) {
      this.metricsHistory.set(serverId, []);
    }

    const history = this.metricsHistory.get(serverId);
    history.push({
      ...metrics,
      timestamp: new Date()
    });

    // Keep only the last N entries
    if (history.length > this.maxHistorySize) {
      history.shift();
    }
  }

  getServerHistory(serverId, hours = 24) {
    const history = this.metricsHistory.get(serverId) || [];
    const cutoffTime = new Date(Date.now() - hours * 60 * 60 * 1000);
    
    return history.filter(metric => metric.timestamp > cutoffTime);
  }

  updateConnectionMetrics(metrics) {
    this.connectionMetrics = {
      ...this.connectionMetrics,
      ...metrics,
      timestamp: new Date()
    };
  }

  addAlert(alert) {
    this.alerts.push({
      id: Date.now(),
      ...alert,
      resolved: false
    });

    // Keep only the last 100 alerts
    if (this.alerts.length > 100) {
      this.alerts = this.alerts.slice(-100);
    }
  }

  resolveAlert(alertId) {
    const alert = this.alerts.find(a => a.id === alertId);
    if (alert) {
      alert.resolved = true;
      alert.resolvedAt = new Date();
    }
  }

  getDashboardData() {
    const servers = Array.from(this.servers.values());
    const activeServers = servers.filter(s => s.status === 'healthy').length;
    
    // Calculate aggregated metrics
    let totalConnections = 0;
    let avgResponseTime = 0;
    let avgCpuUsage = 0;
    let avgMemoryUsage = 0;
    let totalThroughput = 0;
    let count = 0;

    servers.forEach(server => {
      if (server.currentMetrics) {
        totalConnections += server.currentMetrics.activeSessions || 0;
        avgResponseTime += server.currentMetrics.avgResponseTime || 0;
        avgCpuUsage += server.currentMetrics.cpuUsage || 0;
        avgMemoryUsage += server.currentMetrics.memoryUsage || 0;
        totalThroughput += server.currentMetrics.throughput || 0;
        count++;
      }
    });

    if (count > 0) {
      avgResponseTime /= count;
      avgCpuUsage /= count;
      avgMemoryUsage /= count;
    }

    return {
      overview: {
        activeServers,
        totalServers: servers.length,
        totalConnections,
        avgResponseTime: Math.round(avgResponseTime),
        avgCpuUsage: Math.round(avgCpuUsage),
        avgMemoryUsage: Math.round(avgMemoryUsage),
        totalThroughput: Math.round(totalThroughput)
      },
      servers: servers.map(server => ({
        ...server,
        metrics: server.currentMetrics || {}
      })),
      connectionMetrics: this.connectionMetrics,
      alerts: this.alerts.filter(a => !a.resolved).slice(-10),
      lastUpdated: new Date()
    };
  }

  getPerformanceData(timeRange = '24h') {
    const servers = Array.from(this.servers.values());
    
    // Determine how many hours of history to fetch
    const hoursMap = {
      '1h': 1,
      '6h': 6,
      '24h': 24,
      '7d': 168,
      '30d': 720
    };
    const hours = hoursMap[timeRange] || 24;

    // Process data from each server
    const databases = servers.map(server => {
      const history = this.getServerHistory(server.id, hours);
      
      // Calculate trends
      const recentMetrics = server.currentMetrics || {};
      const oldMetrics = history[0] || {};
      
      const calculateTrend = (current, old) => {
        if (!old || old === 0) return 0;
        return ((current - old) / old) * 100;
      };

      return {
        id: server.id,
        name: server.name,
        status: server.status,
        cpu: recentMetrics.cpuUsage || 0,
        memory: recentMetrics.memoryUsage || 0,
        disk: recentMetrics.diskUsage || 0,
        responseTime: recentMetrics.avgResponseTime || 0,
        throughput: recentMetrics.throughput || 0,
        connections: recentMetrics.activeSessions || 0,
        trends: {
          cpu: calculateTrend(recentMetrics.cpuUsage, oldMetrics.cpuUsage),
          memory: calculateTrend(recentMetrics.memoryUsage, oldMetrics.memoryUsage),
          responseTime: calculateTrend(recentMetrics.avgResponseTime, oldMetrics.avgResponseTime),
          throughput: calculateTrend(recentMetrics.throughput, oldMetrics.throughput)
        },
        history: history.map(h => ({
          time: new Date(h.timestamp).toLocaleTimeString(),
          cpu: h.cpuUsage,
          memory: h.memoryUsage,
          responseTime: h.avgResponseTime,
          throughput: h.throughput
        }))
      };
    });

    // Calculate aggregated metrics
    const overview = this.calculateOverviewMetrics(databases);

    return {
      overview,
      databases,
      timeRange,
      lastUpdated: new Date()
    };
  }

  calculateOverviewMetrics(databases) {
    const activeDbs = databases.filter(db => db.status === 'healthy');
    const count = activeDbs.length || 1;

    const avgQueryTime = activeDbs.reduce((sum, db) => sum + db.responseTime, 0) / count;
    const throughput = activeDbs.reduce((sum, db) => sum + db.throughput, 0);
    const cacheHitRatio = 85 + Math.random() * 10; // Simulated
    const cpuUsage = activeDbs.reduce((sum, db) => sum + db.cpu, 0) / count;
    const memoryUsage = activeDbs.reduce((sum, db) => sum + db.memory, 0) / count;
    const activeConnections = activeDbs.reduce((sum, db) => sum + db.connections, 0);

    return {
      avgQueryTime: Math.round(avgQueryTime),
      throughput: Math.round(throughput),
      cacheHitRatio: Math.round(cacheHitRatio),
      cpuUsage: Math.round(cpuUsage),
      memoryUsage: Math.round(memoryUsage),
      activeConnections
    };
  }

  getAlerts(resolved = false) {
    return this.alerts.filter(a => a.resolved === resolved);
  }

  clearResolvedAlerts() {
    this.alerts = this.alerts.filter(a => !a.resolved);
  }
}

module.exports = new DataStore();