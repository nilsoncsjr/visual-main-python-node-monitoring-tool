// backend/src/services/sourcesInstana.js
const logger = require('../utils/logger');

// Limited to 5 metrics per plugin to avoid 422 errors
const MONGO_KEYS_PRIMARY = [
  'process.cpu.util',
  'process.mem.used.pct',
  'process.fs.usage.pct',
  'mongodb.connections.current',
  'mongodb.opcounters.query.rate'
];

const SOLR_KEYS_PRIMARY = [
  'process.cpu.util',
  'process.mem.used.pct',
  'process.fs.usage.pct',
  'solr.http.connections',
  'solr.request.count.rate'
];

// Helper to pick metric value from candidates
function pick(candidates, values, defaultValue = 0.0) {
  for (const key of candidates) {
    if (values[key] !== undefined) {
      return values[key];
    }
  }
  return defaultValue;
}

async function fetchMongoDBRows(instanaClient) {
  if (!instanaClient.isConfigured()) {
    return [];
  }

  try {
    const snapshots = await instanaClient.listEntities('mongodb');
    const ids = snapshots
      .map(s => s.id)
      .filter(id => id); // Filter out empty IDs
    
    if (ids.length === 0) {
      logger.info('No MongoDB instances with valid IDs found in Instana');
      return [];
    }
    
    const metricsData = await instanaClient.metricsLatest(
      'mongodb',
      ids,
      MONGO_KEYS_PRIMARY
    );

    const rows = [];
    for (const snapshot of snapshots) {
      const sid = snapshot.id;
      if (!sid) continue;
      
      const label = snapshot.label || snapshot.name || sid;
      const vals = metricsData[sid] || {};
      
      rows.push({
        instance: label,
        timestamp: null, // Will be set by endpoint
        cpu_usage: pick(['process.cpu.util'], vals),
        memory_usage: pick(['process.mem.used.pct'], vals),
        disk_usage: pick(['process.fs.usage.pct'], vals),
        active_connections: Math.round(pick(['mongodb.connections.current'], vals)),
        active_databases: 0,
        failed_connections: 0,
        query_throughput: pick(['mongodb.opcounters.query.rate'], vals),
        database_type: 'MongoDB',
        // Performance fields (contract uses *_pct)
        cpu_usage_pct: pick(['process.cpu.util'], vals),
        memory_usage_pct: pick(['process.mem.used.pct'], vals),
        disk_usage_pct: pick(['process.fs.usage.pct'], vals)
      });
    }
    
    logger.info(`Fetched ${rows.length} MongoDB instances from Instana`);
    return rows;
  } catch (error) {
    logger.error('Error fetching MongoDB data from Instana:', error.message);
    return [];
  }
}

async function fetchSolrRows(instanaClient) {
  if (!instanaClient.isConfigured()) {
    return [];
  }

  try {
    const snapshots = await instanaClient.listEntities('solr');
    const ids = snapshots
      .map(s => s.id)
      .filter(id => id); // Filter out empty IDs
    
    if (ids.length === 0) {
      logger.info('No Solr instances with valid IDs found in Instana');
      return [];
    }
    
    const metricsData = await instanaClient.metricsLatest(
      'solr',
      ids,
      SOLR_KEYS_PRIMARY
    );

    const rows = [];
    for (const snapshot of snapshots) {
      const sid = snapshot.id;
      if (!sid) continue;
      
      const label = snapshot.label || snapshot.name || sid;
      const vals = metricsData[sid] || {};
      
      rows.push({
        instance: label,
        timestamp: null, // Will be set by endpoint
        cpu_usage: pick(['process.cpu.util'], vals),
        memory_usage: pick(['process.mem.used.pct'], vals),
        disk_usage: pick(['process.fs.usage.pct'], vals),
        active_connections: Math.round(pick(['solr.http.connections'], vals)),
        active_databases: 0,
        failed_connections: 0,
        query_throughput: pick(['solr.request.count.rate'], vals),
        database_type: 'Solr',
        // Performance fields
        cpu_usage_pct: pick(['process.cpu.util'], vals),
        memory_usage_pct: pick(['process.mem.used.pct'], vals),
        disk_usage_pct: pick(['process.fs.usage.pct'], vals)
      });
    }
    
    logger.info(`Fetched ${rows.length} Solr instances from Instana`);
    return rows;
  } catch (error) {
    logger.error('Error fetching Solr data from Instana:', error.message);
    return [];
  }
}

module.exports = {
  fetchMongoDBRows,
  fetchSolrRows
};