const express = require('express');
const cors = require('cors');
const compression = require('compression');
const helmet = require('helmet');
const cron = require('node-cron');
const dotenv = require('dotenv');
const logger = require('./utils/logger');
const metricsCollector = require('./services/metricsCollector');
const dataStore = require('./services/dataStore');

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(helmet());
app.use(compression());
app.use(cors({
  origin: function(origin, callback) {
    // Allow requests with no origin (like mobile apps or Postman)
    if (!origin) return callback(null, true);
    
    // List of allowed origins
    const allowedPatterns = [
      /^http:\/\/localhost:\d+$/  // Any localhost port
    ];
    
    // Add production domains if configured
    if (process.env.ALLOWED_ORIGINS) {
      const additionalOrigins = process.env.ALLOWED_ORIGINS.split(',');
      additionalOrigins.forEach(origin => {
        allowedPatterns.push(new RegExp(`^${origin.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`));
      });
    }
    
    const isAllowed = allowedPatterns.some(pattern => pattern.test(origin));
    
    // Log for debugging in development
    if (process.env.NODE_ENV === 'development') {
      console.log('CORS check - Origin:', origin, 'Allowed:', isAllowed);
    }
    
    callback(null, isAllowed);
  },
  credentials: true
}));
app.use(express.json());

// Routes
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/dashboards', require('./routes/dashboards')); // New dashboard endpoint
app.use('/api/performance', require('./routes/performance'));
app.use('/api/performance/live', require('./routes/performance-live')); // Live performance endpoint
app.use('/api/connections', require('./routes/connections'));
app.use('/api/connections/live', require('./routes/connections-live')); // Live connections endpoint
app.use('/api/backups/live', require('./routes/backups-live')); // Live backups endpoint
app.use('/api/alerts', require('./routes/alerts'));
app.use('/api/metrics', require('./routes/metrics'));
app.use('/api/instana', require('./routes/instana-health')); // Instana health check

// Health check route
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    uptime: process.uptime(),
    timestamp: new Date().toISOString()
  });
});

// Error handling
app.use((err, req, res, next) => {
  logger.error('Application error:', err);
  res.status(500).json({ 
    error: 'Internal server error',
    message: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// Initialize metrics collection
async function initializeMetricsCollection() {
  logger.info('Starting initial metrics collection...');
  
  // Initial collection
  await metricsCollector.collectAllMetrics();
  
  // Schedule periodic collection
  const interval = process.env.COLLECTION_INTERVAL || 5;
  cron.schedule(`*/${interval} * * * *`, async () => {
    logger.info('Running scheduled metrics collection...');
    await metricsCollector.collectAllMetrics();
  });
  
  logger.info(`Metrics collection scheduled every ${interval} minutes`);
}

// Start server
app.listen(PORT, () => {
  logger.info(`Server running on port ${PORT}`);
  logger.info(`Frontend URL: ${process.env.FRONTEND_URL}`);
  
  // Initialize metrics collection
  initializeMetricsCollection().catch(err => {
    logger.error('Error initializing metrics collection:', err);
  });
});