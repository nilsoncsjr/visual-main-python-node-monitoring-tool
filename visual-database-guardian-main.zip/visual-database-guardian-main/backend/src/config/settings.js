// backend/src/config/settings.js
const ENV = process.env.ENV || 'prod';

let INSTANA_BASE_URL, INSTANA_API_TOKEN;

if (ENV === 'dev') {
  INSTANA_BASE_URL = (process.env.INSTANA_BASE_URL_DEV || '').replace(/\/$/, '');
  INSTANA_API_TOKEN = process.env.INSTANA_API_TOKEN_DEV || '';
} else {
  INSTANA_BASE_URL = (process.env.INSTANA_BASE_URL || '').replace(/\/$/, '');
  INSTANA_API_TOKEN = process.env.INSTANA_API_TOKEN || '';
}

const REQUEST_TIMEOUT_SECONDS = parseFloat(process.env.REQUEST_TIMEOUT_SECONDS || '8');

module.exports = {
  ENV,
  INSTANA_BASE_URL,
  INSTANA_API_TOKEN,
  REQUEST_TIMEOUT_SECONDS
};