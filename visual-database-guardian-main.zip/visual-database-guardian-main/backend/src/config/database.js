const dotenv = require('dotenv');
dotenv.config();

// SQL server configuration
const sqlServers = [];

// Load configuration for up to 6 SQL servers
for (let i = 1; i <= 6; i++) {
  const name = process.env[`SQL_SERVER_${i}_NAME`];
  const connectionString = process.env[`SQL_SERVER_${i}_CONNECTION`];
  
  if (connectionString) {
    // Parse the connection string
    const config = parseConnectionString(connectionString);
    
    sqlServers.push({
      id: i,
      name: name || `SQL Server ${i}`,
      config: {
        ...config,
        options: {
          encrypt: config.encrypt !== undefined ? config.encrypt : false,
          trustServerCertificate: config.trustServerCertificate !== undefined ? config.trustServerCertificate : true,
          enableArithAbort: true,
          connectTimeout: 30000,
          requestTimeout: 30000
        },
        pool: {
          max: 10,
          min: 0,
          idleTimeoutMillis: 30000,
          acquireTimeoutMillis: 30000
        }
      }
    });
    
    console.log(`Configured server ${i}: ${name || `SQL Server ${i}`} - ${config.server}:${config.port}`);
  }
}

// Function to parse connection string
function parseConnectionString(connectionString) {
  const config = {
    server: '',
    database: 'master',
    user: '',
    password: '',
    port: 1433
  };

  // Try URL format first (mssql+pyodbc://...)
  if (connectionString.includes('://')) {
    try {
      // Remove prefix mssql+pyodbc:// or similar
      let cleanUrl = connectionString.replace(/^[^:]+:\/\//, '');
      
      // Separate query parameters
      const [mainPart, queryPart] = cleanUrl.split('?');
      
      // Parse main part (user:pass@host:port/database)
      const regex = /^(?:([^:@]+):([^@]+)@)?([^:\/]+)(?::(\d+))?(?:\/(.+))?$/;
      const match = mainPart.match(regex);
      
      if (match) {
        config.user = match[1] || '';
        config.password = match[2] || '';
        config.server = match[3] || '';
        config.port = parseInt(match[4] || '1433');
        config.database = match[5] || 'master';
      }
      
      // Parse query parameters
      if (queryPart) {
        const params = new URLSearchParams(queryPart);
        
        // Apply encryption settings if present
        if (params.get('Encrypt')) {
          config.encrypt = params.get('Encrypt').toLowerCase() === 'yes';
        }
        
        if (params.get('TrustServerCertificate')) {
          config.trustServerCertificate = params.get('TrustServerCertificate').toLowerCase() === 'yes';
        }
      }
      
      return config;
    } catch (error) {
      console.error('Error parsing URL connection string:', error);
    }
  }
  
  // Try traditional format (Server=...;Database=...;)
  const parts = connectionString.split(';');
  
  parts.forEach(part => {
    const [key, value] = part.split('=');
    if (!key || !value) return;
    
    const normalizedKey = key.trim().toLowerCase();
    const trimmedValue = value.trim();
    
    switch (normalizedKey) {
      case 'server':
      case 'data source':
        // Check if it has a port
        if (trimmedValue.includes(',')) {
          const [server, port] = trimmedValue.split(',');
          config.server = server;
          config.port = parseInt(port);
        } else {
          config.server = trimmedValue;
        }
        break;
      case 'database':
      case 'initial catalog':
        config.database = trimmedValue;
        break;
      case 'user id':
      case 'uid':
      case 'user':
        config.user = trimmedValue;
        break;
      case 'password':
      case 'pwd':
        config.password = trimmedValue;
        break;
      case 'port':
        config.port = parseInt(trimmedValue);
        break;
    }
  });
  
  return config;
}

module.exports = {
  sqlServers,
  parseConnectionString
};