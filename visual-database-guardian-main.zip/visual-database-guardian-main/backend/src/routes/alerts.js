const express = require('express');
const router = express.Router();
const dataStore = require('../services/dataStore');
const logger = require('../utils/logger');

// GET /api/alerts
router.get('/', (req, res) => {
  try {
    const resolved = req.query.resolved === 'true';
    const alerts = dataStore.getAlerts(resolved);
    res.json(alerts);
  } catch (error) {
    logger.error('Error getting alerts:', error);
    res.status(500).json({ error: 'Error getting alerts' });
  }
});

// PUT /api/alerts/:id/resolve
router.put('/:id/resolve', (req, res) => {
  try {
    const alertId = parseInt(req.params.id);
    dataStore.resolveAlert(alertId);
    res.json({ success: true, message: 'Alert resolved' });
  } catch (error) {
    logger.error('Error resolving alert:', error);
    res.status(500).json({ error: 'Error resolving alert' });
  }
});

// DELETE /api/alerts/resolved
router.delete('/resolved', (req, res) => {
  try {
    dataStore.clearResolvedAlerts();
    res.json({ success: true, message: 'Resolved alerts removed' });
  } catch (error) {
    logger.error('Error clearing resolved alerts:', error);
    res.status(500).json({ error: 'Error clearing resolved alerts' });
  }
});

module.exports = router;