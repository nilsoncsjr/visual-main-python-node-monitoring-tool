const express = require('express');
const router = express.Router();
const dataStore = require('../services/dataStore');
const logger = require('../utils/logger');

// GET /api/connections
router.get('/', (req, res) => {
  try {
    const connectionData = {
      metrics: dataStore.connectionMetrics,
      servers: Array.from(dataStore.servers.values()).map(server => ({
        id: server.id,
        name: server.name,
        status: server.status,
        connections: server.currentMetrics?.activeSessions || 0,
        lastChecked: server.lastChecked
      }))
    };
    res.json(connectionData);
  } catch (error) {
    logger.error('Error getting connections data:', error);
    res.status(500).json({ error: 'Error getting connections data' });
  }
});

module.exports = router;