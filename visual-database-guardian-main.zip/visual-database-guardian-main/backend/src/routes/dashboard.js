const express = require('express');
const router = express.Router();
const dataStore = require('../services/dataStore');
const logger = require('../utils/logger');

// GET /api/dashboard
router.get('/', (req, res) => {
  try {
    const dashboardData = dataStore.getDashboardData();
    res.json(dashboardData);
  } catch (error) {
    logger.error('Error getting dashboard data:', error);
    res.status(500).json({ error: 'Error getting dashboard data' });
  }
});

module.exports = router;