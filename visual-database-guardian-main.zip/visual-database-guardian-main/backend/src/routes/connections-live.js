const express = require('express');
const router = express.Router();
const sql = require('mssql');
const logger = require('../utils/logger');
const { sqlServers } = require('../config/database');

// GET /api/connections/live
router.get('/', async (req, res) => {
  try {
    const instancesParam = req.query.instances;
    
    if (!instancesParam) {
      return res.status(400).json({ error: 'Parâmetro instances é obrigatório' });
    }

    const instances = instancesParam.split(',');
    const allResults = [];

    // Query SQL para obter connections por instância
    const query = `
      SET NOCOUNT ON;

      WITH s AS (
          SELECT
              program_name         AS connection_name,
              DB_NAME(database_id) AS database_name,
              login_time,
              status,
              is_user_process
          FROM sys.dm_exec_sessions
          WHERE is_user_process = 1
      ),
      g AS (
          SELECT
              connection_name,
              database_name,
              active_sessions_count   = SUM(CASE WHEN status IN ('running','runnable','suspended') THEN 1 ELSE 0 END),
              inactive_sessions_count = SUM(CASE WHEN status IN ('sleeping') THEN 1 ELSE 0 END),
              min_login_time          = MIN(login_time)
          FROM s
          GROUP BY connection_name, database_name
      )
      SELECT
          instance    = CAST(SERVERPROPERTY('ServerName') AS sysname),
          connection_name,
          database_name,
          duration    = CONCAT(
                          DATEDIFF(MINUTE, g.min_login_time, SYSDATETIME())/60, 'h ',
                          RIGHT('0' + CONVERT(varchar(2), DATEDIFF(MINUTE, g.min_login_time, SYSDATETIME())%60), 2), 'm'
                        ),
          status      = CASE WHEN g.active_sessions_count > 0 THEN N'active' ELSE N'inactive' END,
          active_sessions_count,
          inactive_sessions_count
      FROM g
      WHERE connection_name IS NOT NULL AND database_name IS NOT NULL
      ORDER BY
          CASE WHEN g.active_sessions_count > 0 THEN 0 ELSE 1 END,
          g.active_sessions_count DESC,
          connection_name, database_name;
    `;

    // Para cada instância, executar a query
    for (const instance of instances) {
      try {
        // Buscar a configuração do servidor correspondente
        const server = sqlServers.find(s => s.name === instance);
        
        if (!server) {
          logger.warn(`Instância ${instance} não encontrada nas configurações`);
          continue;
        }

        const pool = await sql.connect(server.config);
        const result = await pool.request().query(query);
        
        // Adicionar os resultados com a instância correta
        const instanceResults = result.recordset.map(row => ({
          instance: instance,
          connection_name: row.connection_name || 'Unknown',
          database_name: row.database_name || 'Unknown',
          duration: row.duration || '0h 00m',
          status: row.status || 'inactive',
          active_sessions_count: row.active_sessions_count || 0,
          inactive_sessions_count: row.inactive_sessions_count || 0
        }));

        allResults.push(...instanceResults);
        await pool.close();
      } catch (instanceError) {
        logger.error(`Erro ao buscar dados da instância ${instance}:`, instanceError);
        // Continuar com as outras instâncias mesmo se uma falhar
      }
    }

    // Ordenar: active primeiro, depois por active_sessions_count desc
    allResults.sort((a, b) => {
      if (a.status === 'active' && b.status === 'inactive') return -1;
      if (a.status === 'inactive' && b.status === 'active') return 1;
      return b.active_sessions_count - a.active_sessions_count;
    });

    res.json(allResults);
  } catch (error) {
    logger.error('Erro ao obter dados de connections live:', error);
    res.status(500).json({ error: 'Erro ao obter dados de connections live' });
  }
});

module.exports = router;