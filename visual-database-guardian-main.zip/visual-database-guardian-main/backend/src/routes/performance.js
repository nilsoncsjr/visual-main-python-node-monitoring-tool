const express = require('express');
const router = express.Router();
const dataStore = require('../services/dataStore');
const logger = require('../utils/logger');

// GET /api/performance
router.get('/', (req, res) => {
  try {
    const timeRange = req.query.timeRange || '24h';
    const performanceData = dataStore.getPerformanceData(timeRange);
    res.json(performanceData);
  } catch (error) {
    logger.error('Error getting performance data:', error);
    res.status(500).json({ error: 'Error getting performance data' });
  }
});

module.exports = router;