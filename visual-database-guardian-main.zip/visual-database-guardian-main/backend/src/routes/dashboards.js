const express = require('express');
const router = express.Router();
const dashboardService = require('../services/dashboardService');
const logger = require('../utils/logger');
const { getInstance } = require('../services/instanaClient');
const { fetchMongoDBRows, fetchSolrRows } = require('../services/sourcesInstana');

// GET /api/dashboards/live?instances=INST1,INST2
router.get('/live', async (req, res) => {
  try {
    const instancesParam = req.query.instances;
    
    if (!instancesParam) {
      return res.status(400).json({ error: 'instances parameter is required' });
    }
    
    const instances = instancesParam.split(',').map(inst => inst.trim());
    logger.info(`Fetching live dashboard data for instances: ${instances.join(', ')}`);
    
    // Get SQL Server data
    const sqlData = await dashboardService.getLiveDashboardData(instances);
    const rows = [...sqlData];
    
    // Add Instana data (MongoDB and Solr)
    try {
      const instanaClient = getInstance();
      const nowISO = new Date().toISOString();
      
      // Fetch MongoDB and Solr data in parallel
      const [mongoRows, solrRows] = await Promise.all([
        fetchMongoDBRows(instanaClient),
        fetchSolrRows(instanaClient)
      ]);
      
      // Add timestamp and append to results
      for (const row of [...mongoRows, ...solrRows]) {
        row.timestamp = nowISO;
        rows.push(row);
      }
    } catch (error) {
      logger.error('Error fetching Instana data:', error.message);
      // Continue with SQL Server data only
    }
    
    // Apply instance filter if not ALL
    const wantedInstances = new Set(instances.filter(i => i && i !== 'ALL'));
    const filteredRows = wantedInstances.size > 0 
      ? rows.filter(r => wantedInstances.has(r.instance))
      : rows;
    
    res.json(filteredRows);
  } catch (error) {
    logger.error('Error fetching live dashboard data:', error);
    res.status(500).json({ error: 'Failed to fetch dashboard data' });
  }
});

module.exports = router;