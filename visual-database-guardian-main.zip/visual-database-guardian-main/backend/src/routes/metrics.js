const express = require('express');
const router = express.Router();
const metricsCollector = require('../services/metricsCollector');
const logger = require('../utils/logger');

// POST /api/metrics/collect
router.post('/collect', async (req, res) => {
  try {
    logger.info('Manual metrics collection started via API');
    const results = await metricsCollector.collectAllMetrics();
    res.json({ 
      success: true, 
      message: 'Metrics collected successfully',
      results 
    });
  } catch (error) {
    logger.error('Error collecting metrics:', error);
    res.status(500).json({ error: 'Error collecting metrics' });
  }
});

module.exports = router;