// backend/src/routes/instana-health.js
const express = require('express');
const router = express.Router();
const { InstanaClient } = require('../services/instanaClient');
const settings = require('../config/settings');
const logger = require('../utils/logger');

// GET /api/instana/health
router.get('/health', async (req, res) => {
  const hasConfig = !!(settings.INSTANA_BASE_URL && settings.INSTANA_API_TOKEN);
  
  if (!hasConfig) {
    logger.warn('Instana health check: Configuration missing');
    logger.warn(`BASE_URL: ${settings.INSTANA_BASE_URL ? 'Set' : 'Missing'}`);
    logger.warn(`API_TOKEN: ${settings.INSTANA_API_TOKEN ? 'Set' : 'Missing'}`);
    return res.json({ 
      ok: false, 
      error: 'Instana not configured',
      details: {
        baseUrlConfigured: !!settings.INSTANA_BASE_URL,
        apiTokenConfigured: !!settings.INSTANA_API_TOKEN
      }
    });
  }
  
  try {
    const client = new InstanaClient();
    // Cheap call to test connectivity
    await client.listEntities('mongodb', 5); // Short TTL for health check
    res.json({ ok: true });
  } catch (error) {
    logger.error('Instana health check failed:', error.message);
    if (error.response?.status === 401) {
      return res.json({ 
        ok: false, 
        error: 'Authentication failed - check API token',
        status: 401
      });
    }
    res.json({ ok: false, error: error.message });
  }
});

module.exports = router;