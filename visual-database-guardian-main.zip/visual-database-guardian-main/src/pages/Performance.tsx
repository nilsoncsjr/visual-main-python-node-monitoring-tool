import { useState, useEffect } from "react";
import { Database, Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { InstanceSelector } from "@/components/InstanceSelector";
import { usePerformance } from "@/contexts/PerformanceContext";
import { isCritical } from "@/lib/thresholds";

export default function Performance() {
  const {
    selectedInstances,
    setSelectedInstances,
    lastUpdated,
    isLoading,
    searchQuery,
    setSearchQuery,
    filteredData,
  } = usePerformance();

  const [localSearch, setLocalSearch] = useState(searchQuery);

  // Debounce da busca
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(localSearch);
    }, 300);

    return () => clearTimeout(timer);
  }, [localSearch, setSearchQuery]);

  const getHealthStatus = (cpu: number, disk: number) => {
    if (isCritical({ cpu, disk })) return "critical";
    if (cpu >= 80 || disk >= 70) return "warning";
    return "healthy";
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "healthy":
        return "bg-success text-success-foreground";
      case "warning":
        return "bg-warning text-warning-foreground";
      case "critical":
        return "bg-destructive text-destructive-foreground";
      default:
        return "bg-secondary text-secondary-foreground";
    }
  };

  const formatTimestamp = (date: Date | null) => {
    if (!date) return "";
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(date);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-foreground">Performance Monitoring</h1>
        {lastUpdated && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Live Data</span>
            <span className="text-foreground">{formatTimestamp(lastUpdated)}</span>
          </div>
        )}
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search instances..."
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <InstanceSelector
          value={selectedInstances}
          onChange={setSelectedInstances}
        />
      </div>

      {/* Database Performance Overview with Critical Count */}
      <Card className="bg-gradient-card border-border/50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-foreground">Database Performance Overview</CardTitle>
            {filteredData.length > 0 && (
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Critical Instances:</span>
                <Badge variant={filteredData.filter(r => isCritical({ cpu: r.cpu_usage_pct, disk: r.disk_usage_pct })).length > 0 ? "destructive" : "secondary"}>
                  {filteredData.filter(r => isCritical({ cpu: r.cpu_usage_pct, disk: r.disk_usage_pct })).length}
                </Badge>
              </div>
            )}
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {isLoading && filteredData.length === 0 ? (
              // Loading skeleton
              Array.from({ length: 3 }).map((_, index) => (
                <div
                  key={index}
                  className="p-4 bg-secondary/20 rounded-lg border border-border/50"
                >
                  <Skeleton className="h-6 w-48 mb-4" />
                  <div className="space-y-4">
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                    <Skeleton className="h-8 w-full" />
                  </div>
                </div>
              ))
            ) : filteredData.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No instances found matching your criteria
              </div>
            ) : (
              filteredData.sort((a, b) => {
                // Sort critical instances first
                const aCrit = isCritical({ cpu: a.cpu_usage_pct, disk: a.disk_usage_pct });
                const bCrit = isCritical({ cpu: b.cpu_usage_pct, disk: b.disk_usage_pct });
                if (aCrit && !bCrit) return -1;
                if (!aCrit && bCrit) return 1;
                return 0;
              }).map((instance) => {
                const isCrit = isCritical({ cpu: instance.cpu_usage_pct, disk: instance.disk_usage_pct });
                const status = isCrit ? "critical" : 
                              (instance.cpu_usage_pct >= 80 || instance.disk_usage_pct >= 70) ? "warning" : "healthy";

                return (
                  <div
                    key={instance.instance}
                    className="p-4 bg-secondary/20 rounded-lg border border-border/50 hover:border-primary/30 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <Database className="h-5 w-5 text-primary" />
                        <div>
                          <h3 className="font-medium text-foreground">{instance.instance}</h3>
                          <p className="text-sm text-muted-foreground">
                            {(instance as any).database_type || 'SQL Server'} • {instance.timestamp ? new Date(instance.timestamp).toLocaleString() : ''}
                          </p>
                        </div>
                      </div>
                      <Badge className={getStatusColor(status)}>
                        {status.toUpperCase()}
                      </Badge>
                    </div>

                    <div className="space-y-4">
                      {/* CPU Usage */}
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-muted-foreground">CPU Usage</span>
                          <span className="text-foreground font-medium">
                            {instance.cpu_usage_pct.toFixed(1)}%
                          </span>
                        </div>
                        <Progress 
                          value={instance.cpu_usage_pct} 
                          className="h-2"
                        />
                      </div>

                      {/* Memory Usage */}
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-muted-foreground">Memory Usage</span>
                          <span className="text-foreground font-medium">
                            {instance.memory_usage_pct.toFixed(1)}%
                            {instance.memory_used_gb !== undefined && instance.memory_total_gb !== undefined && (
                              <span className="text-muted-foreground ml-2">
                                ({instance.memory_used_gb.toFixed(1)}/{instance.memory_total_gb.toFixed(1)} GB)
                              </span>
                            )}
                          </span>
                        </div>
                        <Progress 
                          value={instance.memory_usage_pct} 
                          className="h-2"
                        />
                      </div>

                      {/* Disk Usage */}
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-muted-foreground">Disk Usage</span>
                          <span className="text-foreground font-medium">
                            {instance.disk_usage_pct.toFixed(1)}%
                            {instance.disk_used_gb !== undefined && instance.disk_total_gb !== undefined && (
                              <span className="text-muted-foreground ml-2">
                                ({instance.disk_used_gb.toFixed(1)}/{instance.disk_total_gb.toFixed(1)} GB)
                              </span>
                            )}
                          </span>
                        </div>
                        <Progress 
                          value={instance.disk_usage_pct} 
                          className="h-2"
                        />
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}