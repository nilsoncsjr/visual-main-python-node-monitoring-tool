import { useState, useEffect, useMemo } from "react";
import { Database, Search, Activity, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { InstanceSelector } from "@/components/InstanceSelector";
import { useConnections } from "@/contexts/ConnectionsContext";

export default function Connections() {
  const { 
    selectedInstances, 
    setSelectedInstances, 
    connectionsData, 
    lastUpdated, 
    isLoading 
  } = useConnections();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [debouncedSearchTerm, setDebouncedSearchTerm] = useState("");

  // Debounce search term
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearchTerm(searchTerm);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm]);

  // Filter connections based on search
  const filteredConnections = useMemo(() => {
    if (!connectionsData) return [];
    
    return connectionsData.filter(conn => {
      if (!debouncedSearchTerm) return true;
      
      const searchLower = debouncedSearchTerm.toLowerCase();
      return conn.connection_name.toLowerCase().includes(searchLower) ||
             conn.database_name.toLowerCase().includes(searchLower);
    });
  }, [connectionsData, debouncedSearchTerm]);

  // Connection card component
  const ConnectionCard = ({ connection }: { connection: any }) => {
    const isActive = connection.status === 'active';
    
    return (
      <Card className="bg-card/50 border-border/50 hover:border-primary/30 transition-all duration-300">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Database className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg text-foreground">{connection.connection_name}</CardTitle>
            </div>
            <Badge className={isActive ? "bg-success text-success-foreground" : "bg-muted text-muted-foreground"}>
              {connection.status}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Instance</span>
              <span className="text-foreground font-medium">{connection.instance}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Database</span>
              <span className="text-foreground font-medium">{connection.database_name}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Duration</span>
              <span className="text-foreground font-mono text-xs">{connection.duration}</span>
            </div>
          </div>

          <div className="border-t border-border pt-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-success">{connection.active_sessions_count}</p>
                <p className="text-xs text-muted-foreground">Active</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-muted-foreground">{connection.inactive_sessions_count}</p>
                <p className="text-xs text-muted-foreground">Inactive</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  // Loading skeleton
  const ConnectionSkeleton = () => (
    <Card className="bg-card/50 border-border/50">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <Skeleton className="h-6 w-32" />
          <Skeleton className="h-5 w-16" />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-4 w-24" />
          </div>
          <div className="flex justify-between">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-4 w-24" />
          </div>
          <div className="flex justify-between">
            <Skeleton className="h-4 w-20" />
            <Skeleton className="h-4 w-24" />
          </div>
        </div>
        <div className="border-t border-border pt-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center">
              <Skeleton className="h-8 w-12 mx-auto mb-1" />
              <Skeleton className="h-3 w-16 mx-auto" />
            </div>
            <div className="text-center">
              <Skeleton className="h-8 w-12 mx-auto mb-1" />
              <Skeleton className="h-3 w-16 mx-auto" />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-foreground">Database Connections</h1>
        {lastUpdated && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            Last updated: {lastUpdated.toLocaleTimeString()}
          </div>
        )}
      </div>

      {/* Filters */}
      <Card className="bg-gradient-card border-border/50">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search connections..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-background border-border"
              />
            </div>
            <InstanceSelector 
              value={selectedInstances} 
              onChange={setSelectedInstances}
            />
          </div>
        </CardContent>
      </Card>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="bg-card/50 border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {filteredConnections.filter(c => c.status === 'active').length}
                </p>
                <p className="text-sm text-muted-foreground">Active Connections</p>
              </div>
              <Activity className="h-8 w-8 text-success" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card/50 border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {filteredConnections.reduce((sum, c) => sum + c.active_sessions_count, 0)}
                </p>
                <p className="text-sm text-muted-foreground">Total Active Sessions</p>
              </div>
              <Database className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-card/50 border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold text-foreground">
                  {filteredConnections.reduce((sum, c) => sum + c.inactive_sessions_count, 0)}
                </p>
                <p className="text-sm text-muted-foreground">Total Inactive Sessions</p>
              </div>
              <Database className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Connections Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          // Show skeletons while loading
          Array.from({ length: 6 }).map((_, index) => (
            <ConnectionSkeleton key={index} />
          ))
        ) : filteredConnections.length > 0 ? (
          filteredConnections.map((connection, index) => (
            <ConnectionCard key={`${connection.instance}-${connection.connection_name}-${index}`} connection={connection} />
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <Database className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              {searchTerm ? "No connections found matching your search" : "No active connections"}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}