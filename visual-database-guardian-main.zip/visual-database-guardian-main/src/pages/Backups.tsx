import { useState, useEffect } from "react";
import { Database, Search, Calendar, CheckCircle, AlertCircle, Filter } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { InstanceSelector } from "@/components/InstanceSelector";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useBackups } from "@/contexts/BackupsContext";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { ALL, labelFor } from "@/lib/filterAll";

export default function Backups() {
  const {
    selectedInstances,
    setSelectedInstances,
    selectedDatabases,
    setSelectedDatabases,
    selectedTypes,
    setSelectedTypes,
    selectedSince,
    setSelectedSince,
    searchQuery,
    setSearchQuery,
    filteredData,
    databaseOptions,
    lastUpdated,
    isLoading,
  } = useBackups();

  const [localSearch, setLocalSearch] = useState(searchQuery);
  const [databasesOpen, setDatabasesOpen] = useState(false);

  // Debounce da busca
  useEffect(() => {
    const timer = setTimeout(() => {
      setSearchQuery(localSearch);
    }, 300);

    return () => clearTimeout(timer);
  }, [localSearch, setSearchQuery]);

  // Selecionar todos os databases por padrão quando carregar opções
  useEffect(() => {
    if (databaseOptions.length > 0 && selectedDatabases.length === 0) {
      const params = new URLSearchParams(window.location.search);
      if (!params.get('databases')) {
        setSelectedDatabases(databaseOptions);
      }
    }
  }, [databaseOptions, selectedDatabases.length, setSelectedDatabases]);

  const formatTimestamp = (date: Date | null) => {
    if (!date) return "";
    return new Intl.DateTimeFormat('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    }).format(date);
  };

  const formatBackupDate = (dateString: string) => {
    if (!dateString) return 'Never';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const handleDatabaseToggle = (database: string) => {
    if (selectedDatabases.includes(database)) {
      setSelectedDatabases(selectedDatabases.filter(d => d !== database));
    } else {
      setSelectedDatabases([...selectedDatabases, database]);
    }
  };

  const handleSelectAllDatabases = () => {
    if (selectedDatabases.length === databaseOptions.length) {
      setSelectedDatabases([]);
    } else {
      setSelectedDatabases(databaseOptions);
    }
  };

  const handleTypeToggle = (type: string) => {
    if (selectedTypes.includes(type)) {
      setSelectedTypes(selectedTypes.filter(t => t !== type));
    } else {
      setSelectedTypes([...selectedTypes, type]);
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "Full":
        return "bg-blue-500/10 text-blue-500 border-blue-500/20";
      case "Differential":
        return "bg-amber-500/10 text-amber-500 border-amber-500/20";
      case "Log":
        return "bg-purple-500/10 text-purple-500 border-purple-500/20";
      default:
        return "bg-secondary text-secondary-foreground";
    }
  };

  const getStatusIcon = (status: string) => {
    return status === "Success" ? 
      <CheckCircle className="h-3 w-3" /> : 
      <AlertCircle className="h-3 w-3" />;
  };

  const getStatusColor = (status: string) => {
    return status === "Success" ? 
      "bg-success/10 text-success border-success/20" : 
      "bg-muted text-muted-foreground border-muted";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-foreground">Database Backups</h1>
        {lastUpdated && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Last updated</span>
            <span className="text-foreground">{formatTimestamp(lastUpdated)}</span>
          </div>
        )}
      </div>

      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search backups..."
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        
        <InstanceSelector
          value={selectedInstances}
          onChange={setSelectedInstances}
        />

        {/* Database Selector */}
        <Popover open={databasesOpen} onOpenChange={setDatabasesOpen}>
          <PopoverTrigger asChild>
            <Button variant="outline" className="min-w-[200px] justify-between">
              <span className="truncate">
                {labelFor(selectedDatabases, databaseOptions, "database", "databases")}
              </span>
              <Database className="ml-2 h-4 w-4 opacity-50" />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-[250px] p-0" align="start">
            <div className="p-2 border-b">
              <Button
                variant="ghost"
                size="sm"
                className="w-full justify-start"
                onClick={() => {
                  if (selectedDatabases.includes(ALL)) {
                    setSelectedDatabases([]);
                  } else {
                    setSelectedDatabases([ALL]);
                  }
                }}
              >
                <Checkbox
                  checked={selectedDatabases.includes(ALL)}
                  className="mr-2"
                />
                Select All
              </Button>
            </div>
            <div className="max-h-[300px] overflow-y-auto p-2">
              {databaseOptions.map((database) => (
                <Button
                  key={database}
                  variant="ghost"
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => {
                    let newValue: string[];
                    if (selectedDatabases.includes(ALL)) {
                      newValue = [database];
                    } else if (selectedDatabases.includes(database)) {
                      newValue = selectedDatabases.filter(d => d !== database);
                    } else {
                      newValue = [...selectedDatabases, database];
                    }
                    setSelectedDatabases(newValue.length ? newValue : [ALL]);
                  }}
                >
                  <Checkbox
                    checked={selectedDatabases.includes(database) && !selectedDatabases.includes(ALL)}
                    className="mr-2"
                  />
                  <span className="truncate">{database}</span>
                </Button>
              ))}
            </div>
          </PopoverContent>
        </Popover>

        {/* Time Range Selector */}
        <Select value={selectedSince} onValueChange={setSelectedSince}>
          <SelectTrigger className="w-[140px]">
            <Calendar className="mr-2 h-4 w-4 opacity-50" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="24h">Last 24h</SelectItem>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="All">All time</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Filters Row */}
      <div className="flex flex-wrap items-center gap-6">
        {/* Type Filters */}
        <div className="flex items-center gap-4">
          <span className="text-sm text-muted-foreground">Types:</span>
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                if (selectedTypes.length === 3) {
                  setSelectedTypes([]);
                } else {
                  setSelectedTypes(['Full', 'Differential', 'Log']);
                }
              }}
              className="text-xs"
            >
              {selectedTypes.length === 3 ? 'Deselect All' : 'Select All'}
            </Button>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="type-full"
                checked={selectedTypes.includes('Full')}
                onCheckedChange={() => {
                  if (selectedTypes.includes('Full')) {
                    const newTypes = selectedTypes.filter(t => t !== 'Full');
                    setSelectedTypes(newTypes.length ? newTypes : ['Full', 'Differential', 'Log']);
                  } else {
                    setSelectedTypes([...selectedTypes, 'Full']);
                  }
                }}
              />
              <Label htmlFor="type-full" className="text-sm cursor-pointer">Full</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="type-diff"
                checked={selectedTypes.includes('Differential')}
                onCheckedChange={() => {
                  if (selectedTypes.includes('Differential')) {
                    const newTypes = selectedTypes.filter(t => t !== 'Differential');
                    setSelectedTypes(newTypes.length ? newTypes : ['Full', 'Differential', 'Log']);
                  } else {
                    setSelectedTypes([...selectedTypes, 'Differential']);
                  }
                }}
              />
              <Label htmlFor="type-diff" className="text-sm cursor-pointer">Differential</Label>
            </div>
            <div className="flex items-center space-x-2">
              <Checkbox
                id="type-log"
                checked={selectedTypes.includes('Log')}
                onCheckedChange={() => {
                  if (selectedTypes.includes('Log')) {
                    const newTypes = selectedTypes.filter(t => t !== 'Log');
                    setSelectedTypes(newTypes.length ? newTypes : ['Full', 'Differential', 'Log']);
                  } else {
                    setSelectedTypes([...selectedTypes, 'Log']);
                  }
                }}
              />
              <Label htmlFor="type-log" className="text-sm cursor-pointer">Log</Label>
            </div>
          </div>
        </div>
      </div>

      {/* Backups Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading && filteredData.length === 0 ? (
          // Loading skeleton
          Array.from({ length: 6 }).map((_, index) => (
            <Card key={index} className="bg-gradient-card border-border/50">
              <CardContent className="p-6">
                <Skeleton className="h-6 w-3/4 mb-4" />
                <div className="space-y-3">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-2/3" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              </CardContent>
            </Card>
          ))
        ) : filteredData.length === 0 ? (
          <div className="col-span-full text-center py-12 text-muted-foreground">
            No backups found matching your criteria
          </div>
        ) : (
          filteredData.map((backup, index) => (
            <Card 
              key={`${backup.instance}-${backup.database_name}-${backup.type}-${index}`}
              className="bg-gradient-card border-border/50 hover:border-primary/30 transition-colors"
            >
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <h3 className="font-semibold text-foreground truncate flex-1">{backup.database_name}</h3>
                  <Badge 
                    variant="outline" 
                    className={getStatusColor(backup.status)}
                  >
                    {getStatusIcon(backup.status)}
                    <span className="ml-1">{backup.status}</span>
                  </Badge>
                </div>
                
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Instance:</span>
                    <span className="text-foreground font-medium truncate ml-2">{backup.instance}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Size:</span>
                    <span className="text-foreground font-medium">{backup.size}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Type:</span>
                    <Badge 
                      variant="outline" 
                      className={getTypeColor(backup.type)}
                    >
                      {backup.type}
                    </Badge>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Last backup:</span>
                    <span className="text-foreground text-xs">{formatBackupDate(backup.last_backup_date)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}