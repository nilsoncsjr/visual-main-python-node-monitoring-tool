import { Users, Database, AlertTriangle, Lightbulb } from "lucide-react";
import { DashboardKPICard } from "@/components/DashboardKPICard";
import { ResourceUsageChart } from "@/components/ResourceUsageChart";
import { ActivityByInstanceChart } from "@/components/ActivityByInstanceChart";
import { InstanceSelector } from "@/components/InstanceSelector";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DashboardProvider, useDashboard } from "@/contexts/DashboardContext";
import { format } from "date-fns";
import { isCritical } from "@/lib/thresholds";

function DashboardContent() {
  const {
    selectedInstances,
    setSelectedInstances,
    dashboardData,
    timeSeriesData,
    lastUpdated,
    isLoading
  } = useDashboard();

  // Calculate aggregated metrics
  const totalConnections = dashboardData.reduce((sum, d) => sum + d.active_connections, 0);
  const totalDatabases = dashboardData.reduce((sum, d) => sum + d.active_databases, 0);
  const totalFailed = dashboardData.reduce((sum, d) => sum + d.failed_connections, 0);
  
  // Count critical instances using thresholds
  const criticalCount = dashboardData.filter(instance => 
    isCritical({ cpu: instance.cpu_usage, disk: instance.disk_usage })
  ).length;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border/50 bg-card/30 backdrop-blur">
        <div className="px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <h1 className="text-2xl font-bold text-foreground">Python Database Monitoring</h1>
              <InstanceSelector value={selectedInstances} onChange={setSelectedInstances} />
            </div>
            {lastUpdated && (
              <div className="text-sm text-muted-foreground">
                Last Updated: {format(lastUpdated, 'MMM dd, yyyy HH:mm:ss')}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-6 space-y-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <DashboardKPICard
            title="Active Connections"
            value={totalConnections}
            icon={Users}
            color="blue"
            loading={isLoading}
          />
          <DashboardKPICard
            title="Active Databases"
            value={totalDatabases}
            icon={Database}
            color="green"
            loading={isLoading}
          />
          <DashboardKPICard
            title="Failed Connections (24h)"
            value={totalFailed}
            icon={AlertTriangle}
            color={totalFailed > 0 ? "orange" : "green"}
            loading={isLoading}
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ResourceUsageChart data={timeSeriesData} loading={isLoading} />
          <ActivityByInstanceChart data={dashboardData} loading={isLoading} />
        </div>

        {/* Bottom Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Real-Time Alerts */}
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <AlertTriangle className="h-5 w-5 text-orange-500" />
                Real-Time Alerts
              </CardTitle>
            </CardHeader>
            <CardContent>
              {criticalCount > 0 ? (
                <div className="space-y-2">
                  <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                    <p className="text-sm text-foreground">
                      {criticalCount} instance{criticalCount > 1 ? 's' : ''} in critical state (CPU ≥90% or Disk ≥80%)
                    </p>
                  </div>
                </div>
              ) : (
                <p className="text-muted-foreground">No active alerts</p>
              )}
            </CardContent>
          </Card>

          {/* Automated Insights */}
          <Card className="bg-card/50 border-border/50 backdrop-blur">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Lightbulb className="h-5 w-5 text-yellow-500" />
                Automated Insights
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
                  <p className="text-sm text-foreground">
                    Consider optimizing queries on high-traffic databases to reduce response times
                  </p>
                </div>
                <div className="p-3 bg-primary/5 border border-primary/20 rounded-lg">
                  <p className="text-sm text-foreground">
                    Memory usage patterns suggest potential for connection pooling optimization
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  return (
    <DashboardProvider>
      <DashboardContent />
    </DashboardProvider>
  );
}