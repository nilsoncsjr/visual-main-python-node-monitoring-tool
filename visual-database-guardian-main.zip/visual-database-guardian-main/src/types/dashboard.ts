export interface DashboardRow {
  instance: string;
  timestamp: string;
  cpu_usage: number;
  memory_usage: number;
  disk_usage: number;
  active_connections: number;
  active_databases: number;
  failed_connections: number;
  query_throughput: number;
  database_type: string;
}

export interface AggregatedMetrics {
  cpu_avg: number;
  memory_avg: number;
  disk_avg: number;
  total_connections: number;
  total_databases: number;
  total_failed: number;
  total_throughput: number;
}

export interface TimeSeriesPoint {
  timestamp: string;
  cpu_avg: number;
  memory_avg: number;
}