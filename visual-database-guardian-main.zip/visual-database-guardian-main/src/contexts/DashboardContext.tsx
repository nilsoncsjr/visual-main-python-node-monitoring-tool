import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { DashboardRow, TimeSeriesPoint } from '@/types/dashboard';
import { apiService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import { REFRESH_MS } from '@/config/polling';
import { ALL, initAll, nextAll, effective, saveQS } from '@/lib/filterAll';

interface DashboardContextType {
  selectedInstances: string[];
  setSelectedInstances: (instances: string[]) => void;
  dashboardData: DashboardRow[];
  timeSeriesData: TimeSeriesPoint[];
  lastUpdated: Date | null;
  isLoading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
}

const DashboardContext = createContext<DashboardContextType | undefined>(undefined);

const MAX_TIME_SERIES_POINTS = 60; // 60 minutes at 60-second intervals

// Available instances (matching InstanceSelector.tsx)
const AVAILABLE_INSTANCES = [
  "PROD-MSSQL0",
  "PROD-MSSQL2",
  "SIG",
  "sandbox-sql0",
  "dev-sql0",
  "qa-sql0"
];

export function DashboardProvider({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const [selectedInstances, setSelectedInstances] = useState<string[]>([ALL]);
  const [dashboardData, setDashboardData] = useState<DashboardRow[]>([]);
  const [timeSeriesData, setTimeSeriesData] = useState<TimeSeriesPoint[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load selected instances from URL on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const instancesParam = params.get('instances');
    
    if (instancesParam && instancesParam === 'ALL') {
      setSelectedInstances([ALL]);
    } else if (instancesParam) {
      setSelectedInstances(instancesParam.split(','));
    } else {
      // If no parameter, select all instances by default
      setSelectedInstances([ALL]);
      saveQS('instances', [ALL], AVAILABLE_INSTANCES);
    }
  }, []);

  // Update selected instances when they change
  const handleSetSelectedInstances = useCallback((instances: string[]) => {
    const selected = nextAll(instances, AVAILABLE_INSTANCES);
    setSelectedInstances(selected);
    saveQS('instances', selected, AVAILABLE_INSTANCES);
  }, []);

  const refreshData = useCallback(async () => {
    const effectiveInstances = effective(selectedInstances, AVAILABLE_INSTANCES);
    if (effectiveInstances.length === 0) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const data = await apiService.getDashboardLiveData(effectiveInstances);
      setDashboardData(data);
      setLastUpdated(new Date());
      
      // Calculate aggregated metrics for time series
      if (data && data.length > 0) {
        const cpuAvg = data.reduce((sum, d) => sum + d.cpu_usage, 0) / data.length;
        const memAvg = data.reduce((sum, d) => sum + d.memory_usage, 0) / data.length;
        
        const newPoint: TimeSeriesPoint = {
          timestamp: new Date().toISOString(),
          cpu_avg: cpuAvg,
          memory_avg: memAvg
        };
        
        setTimeSeriesData(prev => {
          const updated = [...prev, newPoint];
          // Keep only the last 60 minutes of data
          if (updated.length > MAX_TIME_SERIES_POINTS) {
            return updated.slice(-MAX_TIME_SERIES_POINTS);
          }
          return updated;
        });
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch dashboard data';
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [selectedInstances, toast]);

  // Initial load and polling
  useEffect(() => {
    refreshData();
    
    // Set up polling interval using centralized config
    const interval = setInterval(refreshData, REFRESH_MS);
    
    return () => clearInterval(interval);
  }, [refreshData]);

  return (
    <DashboardContext.Provider
      value={{
        selectedInstances,
        setSelectedInstances: handleSetSelectedInstances,
        dashboardData,
        timeSeriesData,
        lastUpdated,
        isLoading,
        error,
        refreshData
      }}
    >
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboard() {
  const context = useContext(DashboardContext);
  if (context === undefined) {
    throw new Error('useDashboard must be used within a DashboardProvider');
  }
  return context;
}
