import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { apiService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import { REFRESH_MS } from '@/config/polling';
import { ALL, initAll, nextAll, effective, saveQS } from '@/lib/filterAll';

export interface BackupRow {
  instance: string;
  database_name: string;
  size: string;
  size_bytes?: number;
  type: "Full" | "Differential" | "Log";
  last_backup_date: string;
  status: "Success" | "Failed" | "Unknown";
}

type StatusFilter = "ALL" | "Success" | "Failed";

interface BackupsContextType {
  selectedInstances: string[];
  setSelectedInstances: (instances: string[]) => void;
  selectedDatabases: string[];
  setSelectedDatabases: (databases: string[]) => void;
  selectedTypes: string[];
  setSelectedTypes: (types: string[]) => void;
  selectedSince: string;
  setSelectedSince: (since: string) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  backupsData: BackupRow[];
  filteredData: BackupRow[];
  databaseOptions: string[];
  instanceOptions: { value: string; label: string }[];
  lastUpdated: Date | null;
  isLoading: boolean;
  error: string | null;
}

const BackupsContext = createContext<BackupsContextType | null>(null);

// Instances disponíveis
const availableInstances = [
  { value: 'PROD-MSSQL0', label: 'PROD-MSSQL0' },
  { value: 'PROD-MSSQL2', label: 'PROD-MSSQL2' },
  { value: 'SIG', label: 'SIG' },
  { value: 'sandbox-sql0', label: 'sandbox-sql0' },
  { value: 'dev-sql0', label: 'dev-sql0' },
  { value: 'qa-sql0', label: 'qa-sql0' },
];

export function BackupsProvider({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const [selectedInstances, setSelectedInstances] = useState<string[]>([ALL]);
  const [selectedDatabases, setSelectedDatabases] = useState<string[]>([ALL]);
  const [selectedTypes, setSelectedTypes] = useState<string[]>(['Full', 'Differential', 'Log']);
  const [selectedSince, setSelectedSince] = useState<string>('7d');
  const [searchQuery, setSearchQuery] = useState('');
  const [backupsData, setBackupsData] = useState<BackupRow[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Extract unique database options from current data
  const databaseOptions = Array.from(
    new Set(backupsData.map(b => b.database_name))
  ).sort();
  
  const instanceOptions = availableInstances;

  // Handlers para multi-select
  const handleSetSelectedInstances = useCallback((instances: string[]) => {
    const allInstanceValues = availableInstances.map(i => i.value);
    const selected = nextAll(instances, allInstanceValues);
    setSelectedInstances(selected);
    saveQS('instances', selected, allInstanceValues);
  }, []);

  const handleSetSelectedDatabases = useCallback((databases: string[]) => {
    const selected = nextAll(databases, databaseOptions);
    setSelectedDatabases(selected);
    saveQS('databases', selected, databaseOptions);
  }, [databaseOptions]);

  // Initialize from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const instancesParam = params.get('instances');
    const databasesParam = params.get('databases');
    const typesParam = params.get('types');
    const sinceParam = params.get('since');
    const searchParam = params.get('q');
    
    // Instances - default to ALL if not specified
    if (instancesParam === 'ALL' || !instancesParam) {
      setSelectedInstances([ALL]);
    } else {
      const instances = instancesParam.split(',').filter(Boolean);
      setSelectedInstances(instances.length ? instances : [ALL]);
    }

    // Databases - default to ALL if not specified
    if (databasesParam === 'ALL' || !databasesParam) {
      setSelectedDatabases([ALL]);
    } else {
      const databases = databasesParam.split(',').filter(Boolean);
      setSelectedDatabases(databases.length ? databases : [ALL]);
    }

    // Types
    if (typesParam) {
      const types = typesParam.split(',').filter(Boolean);
      if (types.length) setSelectedTypes(types);
    }

    // Since
    if (sinceParam) {
      setSelectedSince(sinceParam);
    }

    // Search
    if (searchParam) {
      setSearchQuery(searchParam);
    }
  }, []);

  // Sync state with URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    
    // Instances
    const instValue = selectedInstances.includes(ALL) ? 'ALL' : selectedInstances.join(',');
    if (instValue === 'ALL') {
      params.delete('instances');
    } else {
      params.set('instances', instValue);
    }
    
    // Databases
    const dbValue = selectedDatabases.includes(ALL) ? 'ALL' : selectedDatabases.join(',');
    if (dbValue === 'ALL') {
      params.delete('databases');
    } else {
      params.set('databases', dbValue);
    }
    
    // Types
    if (selectedTypes.length > 0 && selectedTypes.length < 3) {
      params.set('types', selectedTypes.join(','));
    } else {
      params.delete('types');
    }
    
    // Since
    if (selectedSince && selectedSince !== '7d') {
      params.set('since', selectedSince);
    } else {
      params.delete('since');
    }
    
    // Search
    if (searchQuery) {
      params.set('q', searchQuery);
    } else {
      params.delete('q');
    }
    
    window.history.replaceState(null, '', `${window.location.pathname}?${params.toString()}`);
  }, [selectedInstances, selectedDatabases, selectedTypes, selectedSince, searchQuery]);

  // Load backups data
  const loadBackupsData = useCallback(async () => {
    const effectiveInstances = effective(selectedInstances, availableInstances.map(i => i.value));
    const effectiveDatabases = effective(selectedDatabases, databaseOptions);
    
    if (effectiveInstances.length === 0) {
      setBackupsData([]);
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      
      const data = await apiService.getBackupsLiveData(
        effectiveInstances,
        effectiveDatabases,
        selectedTypes,
        selectedSince
      );
      setBackupsData(data);
      setLastUpdated(new Date());
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch backups data';
      console.error('Error loading backups data:', err);
      
      // Don't show errors as destructive for timeouts, just show available data
      if (errorMessage.includes('timeout') || errorMessage.includes('aborted')) {
        setError('Some instances are taking too long to respond. Showing available data.');
        toast({
          title: "Partial Data",
          description: "Some instances are not responding. Showing available data.",
        });
      } else {
        setError(errorMessage);
        toast({
          title: "Error",
          description: errorMessage,
          variant: "destructive",
        });
      }
    } finally {
      setIsLoading(false);
    }
  }, [selectedInstances, selectedDatabases, selectedTypes, selectedSince, databaseOptions, toast]);

  // Estratégia de atualização: sem dependências para evitar múltiplos intervals
  useEffect(() => {
    let mounted = true;
    let inFlight = false;
    
    const fetchNow = async () => {
      if (inFlight || !mounted) return;
      inFlight = true;
      try {
        await loadBackupsData();
        if (mounted) {
          setLastUpdated(new Date());
        }
      } finally {
        inFlight = false;
      }
    };

    // 1) Load ao entrar na página
    fetchNow();

    // 2) Refetch em foco/visibilidade
    const onFocus = () => {
      if (document.visibilityState === "visible") {
        fetchNow();
      }
    };
    
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onFocus);

    // 3) Intervalo de 1 min enquanto montado
    const intervalId = window.setInterval(fetchNow, REFRESH_MS);

    return () => {
      mounted = false;
      window.clearInterval(intervalId);
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onFocus);
    };
  }, []); // <— sem dependências, para não criar múltiplos intervals
  
  // Refetch quando filtros mudarem (sem criar novo intervalo)
  useEffect(() => {
    loadBackupsData();
  }, [selectedInstances, selectedDatabases, selectedTypes, selectedSince]);

  // Filter data based on search only (removed status filter)
  const filteredData = backupsData.filter(row => {
    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const matches = row.database_name.toLowerCase().includes(query) ||
                     row.instance.toLowerCase().includes(query);
      if (!matches) return false;
    }
    
    return true;
  });

  const value = {
    selectedInstances,
    setSelectedInstances: handleSetSelectedInstances,
    selectedDatabases,
    setSelectedDatabases: handleSetSelectedDatabases,
    selectedTypes,
    setSelectedTypes,
    selectedSince,
    setSelectedSince,
    searchQuery,
    setSearchQuery,
    backupsData,
    filteredData,
    databaseOptions,
    instanceOptions,
    lastUpdated,
    isLoading,
    error,
  };

  return (
    <BackupsContext.Provider value={value}>
      {children}
    </BackupsContext.Provider>
  );
}

export function useBackups() {
  const context = useContext(BackupsContext);
  if (!context) {
    throw new Error('useBackups must be used within a BackupsProvider');
  }
  return context;
}