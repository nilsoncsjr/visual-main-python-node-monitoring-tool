import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { apiService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import { REFRESH_MS } from '@/config/polling';
import { ALL } from '@/lib/filterAll';

interface ConnectionData {
  instance: string;
  connection_name: string;
  database_name: string;
  duration: string;
  status: 'active' | 'inactive';
  active_sessions_count: number;
  inactive_sessions_count: number;
}

interface ConnectionsContextType {
  selectedInstances: string[];
  setSelectedInstances: (instances: string[]) => void;
  connectionsData: ConnectionData[];
  lastUpdated: Date | null;
  isLoading: boolean;
  error: string | null;
  refreshData: () => Promise<void>;
}

const ConnectionsContext = createContext<ConnectionsContextType | undefined>(undefined);

// Available instances (matching DashboardContext)
const AVAILABLE_INSTANCES = [
  "PROD-MSSQL0",
  "PROD-MSSQL2",
  "SIG",
  "sandbox-sql0",
  "dev-sql0",
  "qa-sql0"
];

export function ConnectionsProvider({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const [selectedInstances, setSelectedInstances] = useState<string[]>([ALL]);
  const [connectionsData, setConnectionsData] = useState<ConnectionData[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load selected instances from URL on mount
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const instancesParam = params.get('instances');
    
    if (instancesParam) {
      // If there's a parameter, use it
      setSelectedInstances(instancesParam.split(','));
    } else {
      // If no parameter, select all instances and update URL
      setSelectedInstances(AVAILABLE_INSTANCES);
      params.set('instances', AVAILABLE_INSTANCES.join(','));
      window.history.replaceState({}, '', `${window.location.pathname}?${params.toString()}`);
    }
  }, []);

  // Update URL when instances change
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    
    if (selectedInstances.length > 0) {
      // Always persist selected instances to URL
      params.set('instances', selectedInstances.join(','));
      const newUrl = `${window.location.pathname}?${params.toString()}`;
      window.history.replaceState({}, '', newUrl);
    }
  }, [selectedInstances]);

  const refreshData = useCallback(async () => {
    if (selectedInstances.length === 0) return;
    
    setIsLoading(true);
    setError(null);
    
    try {
      const data = await apiService.getConnectionsLiveData(selectedInstances);
      setConnectionsData(data);
      setLastUpdated(new Date());
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch connections data';
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [selectedInstances, toast]);

  // Initial load and polling
  useEffect(() => {
    refreshData();
    
    // Set up polling interval using centralized config
    const interval = setInterval(refreshData, REFRESH_MS);
    
    return () => clearInterval(interval);
  }, [refreshData]);

  return (
    <ConnectionsContext.Provider
      value={{
        selectedInstances,
        setSelectedInstances,
        connectionsData,
        lastUpdated,
        isLoading,
        error,
        refreshData
      }}
    >
      {children}
    </ConnectionsContext.Provider>
  );
}

export function useConnections() {
  const context = useContext(ConnectionsContext);
  if (context === undefined) {
    throw new Error('useConnections must be used within a ConnectionsProvider');
  }
  return context;
}