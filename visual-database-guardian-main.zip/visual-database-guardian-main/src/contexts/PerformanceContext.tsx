import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { apiService } from '@/services/api';
import { useToast } from '@/hooks/use-toast';
import { REFRESH_MS } from '@/config/polling';
import { ALL, initAll, nextAll, effective, saveQS } from '@/lib/filterAll';

export interface PerformanceRow {
  instance: string;
  timestamp: string;
  cpu_usage_pct: number;
  memory_usage_pct: number;
  disk_usage_pct: number;
  memory_used_gb?: number;
  memory_total_gb?: number;
  disk_used_gb?: number;
  disk_total_gb?: number;
  database_type?: string;
}

interface PerformanceContextType {
  selectedInstances: string[];
  setSelectedInstances: (instances: string[]) => void;
  performanceData: PerformanceRow[];
  lastUpdated: Date | null;
  isLoading: boolean;
  error: string | null;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  filteredData: PerformanceRow[];
}

const PerformanceContext = createContext<PerformanceContextType | null>(null);

// Instances disponíveis (mesmo padrão das outras páginas)
const availableInstances = [
  { value: 'PROD-MSSQL0', label: 'PROD-MSSQL0' },
  { value: 'PROD-MSSQL2', label: 'PROD-MSSQL2' },
  { value: 'SIG', label: 'SIG' },
  { value: 'sandbox-sql0', label: 'sandbox-sql0' },
  { value: 'dev-sql0', label: 'dev-sql0' },
  { value: 'qa-sql0', label: 'qa-sql0' },
];

export function PerformanceProvider({ children }: { children: React.ReactNode }) {
  const { toast } = useToast();
  const [selectedInstances, setSelectedInstances] = useState<string[]>([ALL]);
  const [performanceData, setPerformanceData] = useState<PerformanceRow[]>([]);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Inicializar selectedInstances do URL ou usar ALL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const instancesParam = params.get('instances');
    const allInstanceValues = availableInstances.map(opt => opt.value);
    
    if (instancesParam === 'ALL') {
      setSelectedInstances([ALL]);
    } else if (instancesParam) {
      const instances = instancesParam.split(',').filter(Boolean);
      setSelectedInstances(instances.length ? instances : [ALL]);
    } else {
      // Se não houver parâmetro, selecionar ALL e atualizar URL
      setSelectedInstances([ALL]);
      saveQS('instances', [ALL], allInstanceValues);
    }
  }, []);

  // Handler para atualizar instâncias selecionadas
  const handleSetSelectedInstances = useCallback((instances: string[]) => {
    const allInstanceValues = availableInstances.map(opt => opt.value);
    const selected = nextAll(instances, allInstanceValues);
    setSelectedInstances(selected);
    saveQS('instances', selected, allInstanceValues);
  }, []);

  // Função para carregar dados
  const loadPerformanceData = useCallback(async () => {
    const allInstanceValues = availableInstances.map(opt => opt.value);
    const effectiveInstances = effective(selectedInstances, allInstanceValues);
    
    if (effectiveInstances.length === 0) {
      setPerformanceData([]);
      return;
    }

    try {
      setIsLoading(true);
      setError(null);
      
      const data = await apiService.getPerformanceLiveData(effectiveInstances);
      setPerformanceData(data);
      setLastUpdated(new Date());
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to fetch performance data';
      setError(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  }, [selectedInstances, toast]);

  // Auto-polling (1 minuto)
  useEffect(() => {
    let mounted = true;
    
    const fetchData = async () => {
      await loadPerformanceData();
      if (mounted) {
        setLastUpdated(new Date());
      }
    };

    fetchData();
    const interval = setInterval(fetchData, REFRESH_MS);

    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, [loadPerformanceData]);

  // Filtrar dados baseado na busca
  const filteredData = performanceData.filter(row => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return row.instance.toLowerCase().includes(query);
  });

  const value = {
    selectedInstances,
    setSelectedInstances: handleSetSelectedInstances,
    performanceData,
    lastUpdated,
    isLoading,
    error,
    searchQuery,
    setSearchQuery,
    filteredData,
  };

  return (
    <PerformanceContext.Provider value={value}>
      {children}
    </PerformanceContext.Provider>
  );
}

export function usePerformance() {
  const context = useContext(PerformanceContext);
  if (!context) {
    throw new Error('usePerformance must be used within a PerformanceProvider');
  }
  return context;
}