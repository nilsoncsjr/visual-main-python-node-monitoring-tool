import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const data = [
  { time: "00:00", cpu: 45, memory: 65 },
  { time: "02:00", cpu: 52, memory: 68 },
  { time: "04:00", cpu: 48, memory: 72 },
  { time: "06:00", cpu: 61, memory: 75 },
  { time: "08:00", cpu: 73, memory: 78 },
  { time: "10:00", cpu: 68, memory: 82 },
  { time: "12:00", cpu: 75, memory: 85 },
  { time: "14:00", cpu: 82, memory: 88 },
  { time: "16:00", cpu: 78, memory: 85 },
  { time: "18:00", cpu: 85, memory: 82 },
  { time: "20:00", cpu: 72, memory: 78 },
  { time: "22:00", cpu: 58, memory: 72 },
];

interface ResourceChartProps {
  className?: string;
}

export function ResourceChart({ className }: ResourceChartProps) {
  return (
    <Card className={`bg-gradient-card border-border/50 ${className}`}>
      <CardHeader>
        <CardTitle className="text-foreground">Resource Usage</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid 
                strokeDasharray="3 3" 
                stroke="hsl(var(--border))" 
                opacity={0.3}
              />
              <XAxis 
                dataKey="time" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                domain={[0, 100]}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                  color: "hsl(var(--foreground))",
                }}
                labelStyle={{ color: "hsl(var(--muted-foreground))" }}
              />
              <Line
                type="monotone"
                dataKey="cpu"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4, fill: "hsl(var(--primary))" }}
                name="CPU"
              />
              <Line
                type="monotone"
                dataKey="memory"
                stroke="hsl(var(--chart-2))"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4, fill: "hsl(var(--chart-2))" }}
                name="Memory"
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-center space-x-6 mt-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded-full"></div>
            <span className="text-sm text-muted-foreground">CPU</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-chart-2 rounded-full"></div>
            <span className="text-sm text-muted-foreground">Memory</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}