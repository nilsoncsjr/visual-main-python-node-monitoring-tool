import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DashboardRow } from "@/types/dashboard";
import { Skeleton } from "@/components/ui/skeleton";

const COLORS = [
  "#3B82F6", // Blue
  "#06B6D4", // Cyan
  "#8B5CF6", // Purple
  "#F59E0B", // Orange
  "#10B981", // Green
  "#EF4444", // Red
  "#EC4899", // Pink
];

interface ActivityByInstanceChartProps {
  data: DashboardRow[];
  loading?: boolean;
  className?: string;
}

export function ActivityByInstanceChart({ data, loading, className }: ActivityByInstanceChartProps) {
  if (loading) {
    return (
      <Card className={`bg-card/50 border-border/50 backdrop-blur ${className}`}>
        <CardHeader>
          <CardTitle className="text-foreground">Activity by Instance</CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  const chartData = data.map((row, index) => ({
    name: row.instance,
    value: row.active_connections,
    color: COLORS[index % COLORS.length]
  }));

  const totalConnections = chartData.reduce((sum, item) => sum + item.value, 0);

  return (
    <Card className={`bg-card/50 border-border/50 backdrop-blur ${className}`}>
      <CardHeader>
        <CardTitle className="text-foreground">Activity by Instance</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={chartData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={90}
                paddingAngle={2}
                dataKey="value"
              >
                {chartData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                  color: "hsl(var(--foreground))",
                }}
                formatter={(value: number) => [
                  `${value} connections (${((value / totalConnections) * 100).toFixed(1)}%)`,
                  ""
                ]}
              />
              <Legend
                verticalAlign="bottom"
                height={36}
                iconType="circle"
                wrapperStyle={{
                  color: "hsl(var(--foreground))",
                  fontSize: "14px",
                }}
                formatter={(value: string, entry: any) => 
                  `${value}: ${entry.payload.value}`
                }
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}