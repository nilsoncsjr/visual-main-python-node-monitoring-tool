import { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

interface DashboardKPICardProps {
  title: string;
  value: string | number;
  icon?: LucideIcon;
  color?: 'blue' | 'green' | 'orange' | 'red';
  loading?: boolean;
  className?: string;
}

const colorClasses = {
  blue: 'text-blue-500',
  green: 'text-green-500',
  orange: 'text-orange-500',
  red: 'text-red-500'
};

export function DashboardKPICard({ 
  title, 
  value, 
  icon: Icon, 
  color = 'blue',
  loading = false,
  className 
}: DashboardKPICardProps) {
  if (loading) {
    return (
      <Card className={cn("bg-card/50 border-border/50", className)}>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="space-y-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-8 w-16" />
            </div>
            <Skeleton className="h-12 w-12 rounded-lg" />
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className={cn("bg-card/50 border-border/50 backdrop-blur", className)}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-muted-foreground text-sm font-medium">{title}</p>
            <p className="text-3xl font-semibold text-foreground">{value}</p>
          </div>
          {Icon && (
            <div className={cn(
              "h-12 w-12 rounded-lg flex items-center justify-center bg-background/50",
              colorClasses[color]
            )}>
              <Icon className="h-6 w-6" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}