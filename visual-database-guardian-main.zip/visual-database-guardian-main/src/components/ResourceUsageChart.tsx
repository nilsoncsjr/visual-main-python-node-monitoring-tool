import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TimeSeriesPoint } from "@/types/dashboard";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

interface ResourceUsageChartProps {
  data: TimeSeriesPoint[];
  loading?: boolean;
  className?: string;
}

export function ResourceUsageChart({ data, loading, className }: ResourceUsageChartProps) {
  if (loading) {
    return (
      <Card className={`bg-card/50 border-border/50 backdrop-blur ${className}`}>
        <CardHeader>
          <CardTitle className="text-foreground">Resource Usage</CardTitle>
        </CardHeader>
        <CardContent>
          <Skeleton className="h-64 w-full" />
        </CardContent>
      </Card>
    );
  }

  const formattedData = data.map(point => ({
    ...point,
    time: format(new Date(point.timestamp), 'HH:mm:ss'),
    cpu: Math.round(point.cpu_avg * 10) / 10,
    memory: Math.round(point.memory_avg * 10) / 10
  }));

  return (
    <Card className={`bg-card/50 border-border/50 backdrop-blur ${className}`}>
      <CardHeader>
        <CardTitle className="text-foreground">Resource Usage</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={formattedData}>
              <CartesianGrid 
                strokeDasharray="3 3" 
                stroke="hsl(var(--border))" 
                opacity={0.3}
              />
              <XAxis 
                dataKey="time" 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                interval="preserveStartEnd"
              />
              <YAxis 
                stroke="hsl(var(--muted-foreground))"
                fontSize={12}
                domain={[0, 100]}
                ticks={[0, 25, 50, 75, 100]}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                  color: "hsl(var(--foreground))",
                }}
                labelStyle={{
                  color: "hsl(var(--foreground))",
                }}
                formatter={(value: number) => `${value.toFixed(1)}%`}
              />
              <Legend 
                wrapperStyle={{
                  color: "hsl(var(--foreground))",
                }}
              />
              <Line
                type="monotone"
                dataKey="cpu"
                name="CPU %"
                stroke="#3B82F6"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
              <Line
                type="monotone"
                dataKey="memory"
                name="Memory %"
                stroke="#10B981"
                strokeWidth={2}
                dot={false}
                activeDot={{ r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  );
}