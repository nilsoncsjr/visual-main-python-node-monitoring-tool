import { useState } from "react";
import { NavLink, useLocation } from "react-router-dom";
import {
  Activity,
  BarChart3,
  Database,
  FolderOpen,
  AlertTriangle,
  FileText,
  Settings,
  Menu,
  X,
  Server
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";

const menuItems = [
  { icon: Activity, label: "Dashboard", path: "/" },
  { icon: BarChart3, label: "Performance", path: "/performance" },
  { icon: Database, label: "Connections", path: "/connections" },
  { icon: FolderOpen, label: "Backups", path: "/backups" },
  { icon: AlertTriangle, label: "Alerts", path: "/alerts" },
  { icon: FileText, label: "Logs", path: "/logs" },
  { icon: Settings, label: "Settings", path: "/settings" },
];

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

export function Sidebar({ collapsed, onToggle }: SidebarProps) {
  const location = useLocation();

  return (
    <div 
      className={cn(
        "h-screen bg-gradient-card border-r border-border transition-all duration-300 ease-smooth flex flex-col",
        collapsed ? "w-16" : "w-64"
      )}
    >
      {/* Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          {!collapsed && (
            <div className="flex items-center space-x-3">
              <Server className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-lg font-bold text-foreground">Python</h1>
                <p className="text-xs text-muted-foreground uppercase tracking-wider">
                  Database Monitoring
                </p>
              </div>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={onToggle}
            className="h-8 w-8 p-0 hover:bg-secondary"
          >
            {collapsed ? <Menu className="h-4 w-4" /> : <X className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-2">
        <ul className="space-y-1">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <li key={item.path}>
                <NavLink
                  to={item.path}
                  className={cn(
                    "flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all duration-200",
                    "hover:bg-secondary/50 group",
                    isActive 
                      ? "bg-primary/10 text-primary border border-primary/20 shadow-glow" 
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  <item.icon 
                    className={cn(
                      "h-5 w-5 transition-colors",
                      isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
                    )} 
                  />
                  {!collapsed && (
                    <span className="font-medium">{item.label}</span>
                  )}
                </NavLink>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* Status Footer */}
      {!collapsed && (
        <div className="p-4 border-t border-border">
          <div className="flex items-center space-x-2 text-sm">
            <div className="h-2 w-2 bg-success rounded-full animate-pulse"></div>
            <span className="text-muted-foreground">System Online</span>
          </div>
        </div>
      )}
    </div>
  );
}