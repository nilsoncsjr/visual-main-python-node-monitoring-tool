import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Check, ChevronsUpDown } from "lucide-react";
import { cn } from "@/lib/utils";
import { ALL, labelFor } from "@/lib/filterAll";

// Define the available instances
const availableInstances = [
  { value: "PROD-MSSQL0", label: "PROD-MSSQL0" },
  { value: "PROD-MSSQL2", label: "PROD-MSSQL2" },
  { value: "SIG", label: "SIG" },
  { value: "sandbox-sql0", label: "sandbox-sql0" },
  { value: "dev-sql0", label: "dev-sql0" },
  { value: "qa-sql0", label: "qa-sql0" },
];

interface InstanceSelectorProps {
  value: string[];
  onChange: (value: string[]) => void;
}

export function InstanceSelector({ value, onChange }: InstanceSelectorProps) {
  const [open, setOpen] = useState(false);
  
  const instanceValues = availableInstances.map(i => i.value);
  const isAllSelected = value.includes(ALL);

  const handleSelect = (instance: string) => {
    if (instance === ALL) {
      // If clicking "All", select or deselect all
      onChange(isAllSelected ? [] : [ALL]);
    } else {
      // If clicking a specific instance
      let newValue: string[];
      
      if (isAllSelected) {
        // If "All" is selected, switch to only this instance
        newValue = [instance];
      } else if (value.includes(instance)) {
        // If this instance is already selected, remove it
        newValue = value.filter(v => v !== instance);
        // If nothing is selected after removal, select "All"
        if (newValue.length === 0) {
          newValue = [ALL];
        }
      } else {
        // Add this instance to the selection
        newValue = [...value, instance];
      }
      
      onChange(newValue);
    }
  };

  const selectedLabel = labelFor(value, instanceValues, "instance", "instances");

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-[250px] justify-between bg-card/50 border-border/50 text-foreground hover:bg-card/80"
        >
          <span className="truncate">{selectedLabel}</span>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[250px] p-0 bg-card border-border">
        <Command className="bg-transparent">
          <CommandInput placeholder="Search instances..." className="text-foreground" />
          <CommandList>
            <CommandEmpty>No instance found.</CommandEmpty>
            <CommandGroup>
              {/* "All Instances" option */}
              <CommandItem
                value="all-instances"
                onSelect={() => handleSelect(ALL)}
                className="text-foreground hover:bg-accent/50"
              >
                <Check
                  className={cn(
                    "mr-2 h-4 w-4",
                    isAllSelected ? "opacity-100" : "opacity-0"
                  )}
                />
                All Instances
              </CommandItem>
              {/* Individual instances */}
              {availableInstances.map((instance) => (
                <CommandItem
                  key={instance.value}
                  value={instance.value}
                  onSelect={() => handleSelect(instance.value)}
                  className="text-foreground hover:bg-accent/50"
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      (isAllSelected || value.includes(instance.value)) ? "opacity-100" : "opacity-0"
                    )}
                  />
                  {instance.label}
                </CommandItem>
              ))}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}