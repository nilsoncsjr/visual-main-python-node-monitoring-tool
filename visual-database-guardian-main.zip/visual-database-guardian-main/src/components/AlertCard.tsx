import { AlertTriangle, XCircle, AlertCircle, Info } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export type AlertType = "error" | "warning" | "info" | "critical";

interface AlertCardProps {
  type: AlertType;
  title: string;
  timestamp: string;
  description?: string;
}

const alertConfig = {
  error: {
    icon: XCircle,
    bgColor: "bg-destructive/10",
    borderColor: "border-destructive/30",
    iconColor: "text-destructive",
    badgeVariant: "destructive" as const,
  },
  warning: {
    icon: AlertTriangle,
    bgColor: "bg-warning/10",
    borderColor: "border-warning/30",
    iconColor: "text-warning",
    badgeVariant: "secondary" as const,
  },
  critical: {
    icon: AlertTriangle,
    bgColor: "bg-destructive/20",
    borderColor: "border-destructive/50",
    iconColor: "text-destructive",
    badgeVariant: "destructive" as const,
  },
  info: {
    icon: Info,
    bgColor: "bg-primary/10",
    borderColor: "border-primary/30",
    iconColor: "text-primary",
    badgeVariant: "secondary" as const,
  },
};

export function AlertCard({ type, title, timestamp, description }: AlertCardProps) {
  const config = alertConfig[type];
  const Icon = config.icon;

  return (
    <Card className={cn(
      "border transition-all duration-200 hover:shadow-md",
      config.bgColor,
      config.borderColor
    )}>
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          <div className="flex-shrink-0">
            <Icon className={cn("h-5 w-5", config.iconColor)} />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between mb-1">
              <h4 className="text-sm font-medium text-foreground truncate">
                {title}
              </h4>
              <Badge variant={config.badgeVariant} className="text-xs">
                {type.toUpperCase()}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mb-2">{timestamp}</p>
            {description && (
              <p className="text-sm text-muted-foreground">{description}</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}