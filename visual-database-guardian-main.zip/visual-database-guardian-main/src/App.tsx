import { useState } from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Sidebar } from "@/components/Sidebar";
import { ConnectionsProvider } from "@/contexts/ConnectionsContext";
import { PerformanceProvider } from "@/contexts/PerformanceContext";
import { BackupsProvider } from "@/contexts/BackupsContext";
import Dashboard from "./pages/Dashboard";
import Performance from "./pages/Performance";
import Connections from "./pages/Connections";
import Backups from "./pages/Backups";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  
  // Log para debug
  console.log("App component rendering...");

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <div className="flex min-h-screen w-full bg-background">
            <Sidebar 
              collapsed={sidebarCollapsed} 
              onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} 
            />
            <main className="flex-1 p-6 overflow-auto">
              <Routes>
                <Route path="/" element={<Dashboard />} />
          <Route path="/performance" element={
            <PerformanceProvider>
              <Performance />
            </PerformanceProvider>
          } />
                <Route path="/connections" element={
                  <ConnectionsProvider>
                    <Connections />
                  </ConnectionsProvider>
                } />
                <Route path="/backups" element={
                  <BackupsProvider>
                    <Backups />
                  </BackupsProvider>
                } />
                <Route path="/alerts" element={<div className="text-center text-muted-foreground py-12">Alerts page coming soon...</div>} />
                <Route path="/logs" element={<div className="text-center text-muted-foreground py-12">Logs page coming soon...</div>} />
                <Route path="/settings" element={<div className="text-center text-muted-foreground py-12">Settings page coming soon...</div>} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
          </div>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;