// Configuração centralizada de polling
export const REFRESH_MS = 60_000; // 1 minuto para toda a aplicação