// Utility for handling "All" option in multi-select filters
export const ALL = "__ALL__";

export function initAll(options: string[], current?: string[]): string[] {
  return !options.length || (current && current.length && !current.includes(ALL))
    ? (current ?? [])
    : [ALL];
}

export function nextAll(next: string[], allOptions: string[]): string[] {
  if (!allOptions.length || !next.length || next.includes(ALL)) return [ALL];
  return next;
}

export function effective(selected: string[], allOptions: string[]): string[] {
  return selected.includes(ALL) ? allOptions : selected;
}

export function labelFor(selected: string[], allOptions: string[], singular: string, plural: string): string {
  if (selected.includes(ALL)) return `All ${plural}`;
  return selected.length === 1 ? `1 ${singular} selected` : `${selected.length} ${plural} selected`;
}

export function saveQS(key: string, selected: string[], allOptions: string[]) {
  const qs = new URLSearchParams(location.search);
  if (selected.includes(ALL)) {
    qs.set(key, "ALL");
  } else {
    qs.set(key, selected.join(","));
  }
  history.replaceState(null, "", `${location.pathname}?${qs.toString()}`);
}