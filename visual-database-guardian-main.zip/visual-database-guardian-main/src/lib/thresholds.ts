// Health thresholds for monitoring
export const TH = { CPU: 90, DISK: 80 };

export const isCritical = (r: { cpu?: number; disk?: number }) =>
  (r.cpu ?? 0) >= TH.CPU || (r.disk ?? 0) >= TH.DISK;

export function healthFrom(row: { 
  cpu_usage_pct?: number; 
  disk_usage_pct?: number;
  memory_usage_pct?: number;
  cpu_usage?: number;
  disk_usage?: number;
  memory_usage?: number;
}): "CRITICAL" | "HEALTHY" {
  // Critical if CPU >= 90% or Disk >= 80%
  // Memory does NOT trigger critical status
  const cpu = row.cpu_usage_pct ?? row.cpu_usage ?? 0;
  const disk = row.disk_usage_pct ?? row.disk_usage ?? 0;
  
  return isCritical({ cpu, disk }) ? "CRITICAL" : "HEALTHY";
}