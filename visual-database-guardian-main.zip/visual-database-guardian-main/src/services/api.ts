// API Service for Backend Communication
const API_BASE_URL = 'http://localhost:3001/api';

class ApiService {
  private async fetchWithTimeout(url: string, options: RequestInit = {}, timeout = 30000) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    try {
      const response = await fetch(url, {
        ...options,
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          ...options.headers,
        },
      });

      clearTimeout(timeoutId);

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      if (error instanceof Error) {
        if (error.name === 'AbortError') {
          throw new Error('Request timeout');
        }
        throw error;
      }
      throw new Error('Unknown error occurred');
    }
  }

  // Dashboard
  async getDashboardData() {
    return this.fetchWithTimeout(`${API_BASE_URL}/dashboard`);
  }

  // Performance
  async getPerformanceData(timeRange: string = '24h') {
    return this.fetchWithTimeout(`${API_BASE_URL}/performance?timeRange=${timeRange}`);
  }

  async getPerformanceLiveData(instances: string[]) {
    const instancesParam = instances.join(',');
    return this.fetchWithTimeout(`${API_BASE_URL}/performance/live?instances=${instancesParam}`);
  }

  // Connections
  async getConnectionsData() {
    return this.fetchWithTimeout(`${API_BASE_URL}/connections`);
  }

  async getConnectionsLiveData(instances: string[]) {
    const instancesParam = instances.join(',');
    return this.fetchWithTimeout(`${API_BASE_URL}/connections/live?instances=${instancesParam}`);
  }

  // Backups
  async getBackupsLiveData(instances: string[], databases: string[], types: string[], since: string) {
    const params = new URLSearchParams();
    if (instances.length > 0) params.set('instances', instances.join(','));
    if (databases.length > 0) params.set('databases', databases.join(','));
    if (types.length > 0) params.set('types', types.join(','));
    if (since) params.set('since', since);
    return this.fetchWithTimeout(`${API_BASE_URL}/backups/live?${params.toString()}`);
  }

  // Alerts
  async getAlerts(resolved: boolean = false) {
    return this.fetchWithTimeout(`${API_BASE_URL}/alerts?resolved=${resolved}`);
  }

  async resolveAlert(alertId: number) {
    return this.fetchWithTimeout(`${API_BASE_URL}/alerts/${alertId}/resolve`, {
      method: 'PUT',
    });
  }

  async clearResolvedAlerts() {
    return this.fetchWithTimeout(`${API_BASE_URL}/alerts/resolved`, {
      method: 'DELETE',
    });
  }

  // Metrics
  async collectMetrics() {
    return this.fetchWithTimeout(`${API_BASE_URL}/metrics/collect`, {
      method: 'POST',
    });
  }

  // Health Check
  async healthCheck() {
    return this.fetchWithTimeout(`${API_BASE_URL}/health`);
  }

  // New Dashboard Live Data
  async getDashboardLiveData(instances: string[]) {
    const instancesParam = instances.join(',');
    return this.fetchWithTimeout(`${API_BASE_URL}/dashboards/live?instances=${instancesParam}`);
  }
}

export const apiService = new ApiService();
export default apiService;